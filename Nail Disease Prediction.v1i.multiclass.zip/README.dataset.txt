# Nail Disease Prediction > 2023-03-14 6:07pm
https://universe.roboflow.com/nail-acf3b/nail-disease-prediction

Provided by a Roboflow user
License: CC BY 4.0

